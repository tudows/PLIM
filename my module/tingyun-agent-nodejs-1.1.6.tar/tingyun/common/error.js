'use strict';

var urltils = require('../util/urltils')
    , logger  = require('../util/logger').child('common.error')
    ;

var MAX_ERRORS = 20;

function createError(action, exception, customParameters, config) {
    // the collector throws this out, so don't bother setting it
    var timestamp = (new Date()).getTime() * 0.001
        , name      = 'WebAction/Uri/*'
        , message   = ''
        , type      = 'Error'
        , params    = {
            params  : {},
            requestParams : {},
            stacktrace      : {}
        }
        ;

    if (action && action.name) name = action.name;

    // NB: anything throwing / emitting strings is buggy, but it happens
    if (typeof exception === 'string') {
        message = exception;
    }
    else if (exception && exception.message) {
        message = exception.message;
        // only care about extracting the type if it's Error-like.
        if (exception && exception.constructor && exception.constructor.name) {
            type = exception.constructor.name;
        }
    }
    else if (action &&
        action.statusCode &&
        urltils.errorMatch(config, action.statusCode)) {
        message = 'HttpError ' + action.statusCode;
    }

    if (action && action.url) {
        var url        = action.url
            , statusCode = action.statusCode || 500
            ;

        if (!action.name) {
            var partialName = action.partialName;
            action.setName(url, statusCode);
            action.setPartialName(partialName);
        }

        var custom = action.getTrace().custom;
        Object.keys(custom).forEach(function (param) {
            params.params[param] = custom[param];
        });

        name = action.name;
        if (config.capture_params) {
            var reqParams = action.getTrace().parameters;
            var urlParams = urltils.parseParameters(url);
            // clear out ignored params
            config.ignored_params.forEach(function cb_forEach(k) {
                // polymorphic hidden classes aren't an issue with data bags
                delete urlParams[k];
                delete reqParams[k];
            });

            Object.keys(urlParams).forEach(function (param) {
                params.requestParams[param] = urlParams[param];
            });

            Object.keys(reqParams).forEach(function (param) {
                params.requestParams[param] = reqParams[param];
            });
        }
    }

    if ( customParameters ) {
        var ignored = [];
        if (action) ignored = config.ignored_params;
        Object.keys(customParameters).forEach(function cb_forEach(param) {
            if (ignored.indexOf(param) === -1) params.params[param] = customParameters[param];
        });
    }

    var stack = exception && exception.stack;
    if (stack) params.stacktrace = ('' + stack).split(/[\n\r]/g);
    if ( ! action ) logger.error(exception);

    return [timestamp, (action?name:'BackgroundAction/Error/' + exception.name), (action? action.statusCode: (exception.code || 0)), type, message, 1, action?action.url:'', JSON.stringify(params)];
}


function ErrorTracer(config) {
    this.config     = config;
    this.errorCount = 0;
    this.errors     = [];
    this.seen       = [];
}

ErrorTracer.prototype.onActionFinished = function onActionFinished(action, metrics) {
    if (!action) throw new Error("Error collector got a blank action.");
    if (!metrics) throw new Error("Error collector requires metrics to count errors.");

    if (urltils.errorMatch(this.config, action.statusCode) ||
        (action.statusCode < 1 && action.exceptions.length > 0)) {
        if (action.exceptions.length > 0) {
            action.exceptions.forEach(function cb_forEach(exception) {
                this.add(action, exception);
            }, this);
        }
        else {
            this.add(action);
        }

        var count = metrics.getMetric('Errors/Count/' + action.name.replace(/\//g, "%2F"));
        count.incrementCallCount(1);
    }
};

ErrorTracer.prototype.add = function add(action, exception, customParameters) {
    if (!exception) {
        if (!action) return;
        if (!action.statusCode) return;
        if (action.error) return;
    }
    else {
        if (this.seen.indexOf(exception) !== -1) return;
        if (typeof exception !== 'string' && !exception.message && !exception.stack) {
            return;
        }
    }

    this.errorCount++;

    // allow enabling & disabling the error tracer at runtime
    if (!this.config.error_collector || !this.config.error_collector.enabled) return;

    if (exception) {
        logger.debug(exception, "Got exception to trace:");
        // put the error on the action to show we've already traced it
        if (action) action.error = exception;
        this.seen.push(exception);
    }

    if (this.errors.length < MAX_ERRORS) {
        var  error = createError(action, exception, customParameters, this.config);
        logger.verbose({error : error}, "Error to be sent to collector:");
        this.errors.push(error);
    }
    else {
        logger.verbose("Already have %d errors to send to collector, not keeping.",
            MAX_ERRORS);
    }
};


ErrorTracer.prototype.merge = function merge(errors) {
    if (!errors || errors.length === 0) return;

    var len = Math.min(errors.length, MAX_ERRORS - this.errors.length);
    logger.warning("Merging %s (of %s) errors for next delivery.", len, errors.length);
    for (var i = 0; i < len; i++) this.errors.push(errors[i]);
};

module.exports = ErrorTracer;
