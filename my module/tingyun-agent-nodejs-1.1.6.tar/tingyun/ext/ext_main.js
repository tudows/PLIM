'use strict';
var fs = require('fs');
var ext;
var init = function init() {
    var version = process.versions.node.split('.');
    var ver_part = (version[1] < 11)?10:11;
    var arch = (process.arch === 'ia32')? 'x86': process.arch;
    var module_name = './ext_' + process.platform + '_' + arch + '_' + ver_part + '.node';
    var full_path = require('path').join(process.cwd(), 'node_modules/tingyun/ext', module_name);
    var result = {
        confusion : function confusion(sql) {
            return sql;
        }
    };
    if ( fs.existsSync(full_path) ) {
        try {
            result = require(full_path);
        }
        catch (e) { }
    }
    return result;
}
ext = init();
module.exports = ext;