'use strict';

var logger = require('../util/logger').child('metrics.mapper');

function NameMap(raw) {
  this.unscoped = {};
  this.scoped   = {};
  this.length   = 0;
  this.load(raw);
}

NameMap.prototype.load = function load(raw) {
  if (!(raw && raw.length)) return;
  for (var i = 0; i < raw.length; i++) {
    var spec  = raw[i][0]
      , scope = spec.scope
      , name  = spec.name
      , id    = raw[i][1]
      , resolved
      ;

    if (scope) {
      if (!this.scoped[scope]) this.scoped[scope] = {};
      resolved = this.scoped[scope];
    }
    else resolved = this.unscoped;
    if (!resolved[name]) this.length++;
    resolved[name] = id;
    logger.debug("Metric spec %j has been mapped to ID %s.", spec, id);
  }
  logger.verbose("Parsed %d metric ids (%d total).", raw.length, this.length);
};

NameMap.prototype.map = function map(name, scope) {
  if (scope) {
    if (this.scoped[scope] && this.scoped[scope][name]) {
      return this.scoped[scope][name];
    }
    else return {name : name, scope : scope};
  }
  else {
    if (this.unscoped[name]) return this.unscoped[name];
    else return {name : name};
  }
};

module.exports = NameMap;
