'use strict';
var CallStack= require('../../util/stack');
var shimmer  = require('../../util/shimmer');
var logger   = require('../../util/logger').child('parsers.wrappers.mysql');
var parseSql = require('../db/parse-sql');

module.exports = function initialize(agent, mysql) {
    var tracer = agent.tracer;

    function on_query(query, my_ver) {

        return tracer.segmentProxy(function on_seg_query_proxy(sql, values, callback) {
            if ( ! agent.config.enabled ) return query.apply(this, arguments);
            if (!tracer.getAction() || arguments.length < 1) return query.apply(this, arguments);
            var action = tracer.getAction();
            var actualSql, actualCallback, actualValues;
            // query(options, callback)
            if (typeof sql === 'object') {
                actualSql = sql.sql;
                actualCallback = ( arguments.length === 1 )? sql._callback : values;
            }
            // query(sql, callback)
            else if (typeof values === 'function') {
                actualSql = sql;
                actualCallback = values;
            }
            // query(sql, values, callback)
            else {
                actualSql = sql;
                actualCallback = callback;
                actualValues = values;
            }

            var wrapped;
            if ( typeof actualCallback === 'function' ) wrapped = tracer.callbackProxy(actualCallback);

            var ps = parseSql("Database mysql", actualSql);
            var segment_info = {
                metric_name : ps.metricName(),
                call_url: "",
                call_count:1,
                class_name: ((my_ver == '0.9')?'mysql.Client':'connection'),
                method_name: 'query',
                params : {}
            };
            var sql_trace;
            var ret_callback = wrapped;
            var self = this;
            function on_query_back () {
                var query_end_time = Date.now();
                if ( query_end_time - segment.timer.start >= tracer.agent.config.action_tracer.explain_threshold ) {
                    segment.end();
                    query.call(self, 'explain ' + actualSql, actualValues, function on_explain(err, rows, fields){
                        if ( ! err ) {
                            var keys = [];
                            for ( var i = 0; i < fields.length; i++ ) keys[i] = fields[i].name;

                            var values = [];
                            for ( var r = 0; r < rows.length; r++ ) {
                                var data = [];
                                for ( var i = 0; i < keys.length; i++ ) data[i] = rows[r][keys[i]];
                                values[r] = data;
                            }
                            sql_trace.explainPlan = {
                                dialect : 'mysql',
                                keys    : keys,
                                values  : values
                            };
                        }
                        segment.end(tracer.agent.config, sql_trace);
                    });
                }
                else {
                    segment.end(tracer.agent.config, sql_trace);
                }
                if ( wrapped ) wrapped.apply(this, arguments);
            }

            if ( tracer.agent.config.action_tracer.slow_sql === true ) {
                if ( tracer.agent.config.action_tracer.explain_enabled === true ) ret_callback = on_query_back;
                sql_trace = {
                    sql : actualSql,
                    stack : CallStack("Connection.query", 2),
                };
            }
            var segment = tracer.addSegment(segment_info, ps.recordMetrics.bind(ps));

            if (this.config) {
                segment.port = this.config.port;
                segment.host = this.config.host;
            }
            var returned;
            if ( my_ver === '0.9' ) {
                if ( ! this.config || this.port ) {
                    segment.port = this.port;
                    segment.host = this.host;
                }
                var args    = tracer.slice(arguments);
                if ( args.length < 1 || typeof(args[args.length - 1]) !== 'function' ) {
                    args[args.length] = function tmp(){};
                }
                args[args.length - 1] = ret_callback;
                returned = query.apply(this, args);
            }
            else if ( my_ver === '2.0' ) {
                returned = query.call(this, sql, actualValues, ret_callback);
            }
            returned.once('end', function handle_end() {
                if ( (ret_callback === wrapped) || ! wrapped ) {
                    segment.end(tracer.agent.config, sql_trace);
                }
            });
            return returned;
        });
    }

    function getVargs(args) {
        var callback;
        var vargs = [];
        if (args.length === 1) {
            callback = args[0];
        } else if (args.length === 2) {
            vargs.push(args[0]);
            callback = args[1];
        } else {
            vargs.push(args[0]);
            vargs.push(args[1]);
            callback = args[2];
        }
        logger.debug({args: args, vargs: vargs}, 'parsed getConnection arguments');
        return {
            vargs    : vargs,
            callback : callback,
        };
    }

    function getConnectionHandler(dbObject, getConnectionMethod) {
        return function wrap() { // getConnection
            var args = getVargs(arguments);
            var getConnectionCallback;
            var isCallback = args.callback && typeof args.callback === 'function';

            if (!isCallback || !args.callback.__TY_original_callback) {
                var proxiedCallback = tracer.callbackProxy(args.callback);
                getConnectionCallback = function getConnectionCallback(err, connection) {
                    // we need to patch the connection objects .query method
                    shimmer.wrapMethod(connection, 'connection', 'query', function wp_query(query){
                        return on_query(query, '2.0');
                    });
                    proxiedCallback(err, connection);
                };
                getConnectionCallback.__TY_original_callback = args.callback;
            } else getConnectionCallback = args.callback;

            args.vargs.push(getConnectionCallback);

            return getConnectionMethod.apply(dbObject, args.vargs);
        };
    }


    if (mysql && mysql.createConnection) {
        //node-mysql 2.x
        shimmer.wrapMethod(mysql, 'mysql.prototype', 'createPoolCluster', function cb(createPoolCluster) {

            return function not_in_action() {
                var poolCluster = createPoolCluster.apply(mysql, arguments);

                shimmer.wrapMethod(poolCluster, 'poolCluster', 'of', function cb(of) {
                    return function () {
                        var result = of.apply(poolCluster, arguments);
                        shimmer.wrapMethod(result, 'poolCluster', 'getConnection', function cb(getConnection) {
                            return getConnectionHandler(result, getConnection);
                        });
                        return result;
                    };
                });
                shimmer.wrapMethod(poolCluster, 'poolCluster', 'getConnection', function cb(getConnection) {
                    return getConnectionHandler(poolCluster, getConnection);
                });

                return poolCluster;
            };
        });

        shimmer.wrapMethod(mysql, 'mysql', 'createPool', function cb_wrapMethod(createPool) {
            return function cb_segmentProxy() {
                var pool = createPool.apply(mysql, arguments);
                shimmer.wrapMethod(pool, 'pool', 'getConnection', function cb_wrapMethod(getConnection) {
                    return getConnectionHandler(pool, getConnection);
                });
                //重复hook了，最终会调用connection的query
//                        shimmer.wrapMethod(pool, 'pool', 'query', function on_wrap(query){
//                            return on_query(query, '2.0');
//                        });
                return pool;
            };
        });
        shimmer.wrapMethod(mysql, 'mysql', 'createConnection', function on_conn_create(createConnection) {
            return tracer.segmentProxy( function on_seg_conn_proxy() {
                var connection = createConnection.apply(this, arguments);
                shimmer.wrapMethod(connection, 'connection', 'query', function on_wrap(query){
                    return on_query(query, '2.0');
                });
                return connection;
            });
        });
    }
    else if (mysql && mysql.Client) {
        //node-mysql 0.9.x
        shimmer.wrapMethod( mysql.Client.prototype, 'mysql.Client.prototype', 'query', function on_wrap(query) {
            return on_query(query, '0.9');
        });
    }
};
