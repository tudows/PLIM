'use strict';
var CallStack = require('../../util/stack');
var shimmer   = require('../../util/shimmer');
var urltils   = require('../../util/urltils.js');
var logger    = require('../../util/logger').child('parsers.wrappers.thrift');
var recordExternal = require('../../metrics/recorders/http_external.js');

module.exports = function initialize(agent, thrift) {
    if ( ! thrift ) return;
    var tracer = agent.tracer;

    function find_method(client, name) {
        if ( name.indexOf('send_') === 0 ) {
            var search_name = name.slice(5);
            if (typeof client['recv_' + search_name] === 'function' && typeof client[search_name] === 'function') {
                return search_name;
            }
        }
    }
    if ( ! (thrift.createClient && thrift.Connection && thrift.createConnection && thrift.createServer) ) return;

    function wrap_client_method(thrift, obj_class, method) {

        shimmer.wrapMethod(thrift, 'thrift', method, function cb(createClient) {

            return function wrapper(cls, connection) {

                var class_name = obj_class;
                if ( typeof cls === 'string' ) class_name = cls;

                var ret = createClient.apply(this, arguments);
                if ( (! connection.host || ! connection.options || ! connection.port) && arguments.length > 2 ) {
                    connection = arguments[2];
                }
                var client = ret.__proto__;
                for ( var name in client ) {

                    var method_name = find_method(client, name);
                    if ( method_name ) {
                        if ( client[method_name].__TY_original_callback ) continue;
                        var oragin = client[method_name];
                        shimmer.wrapMethod(client, 'Client', method_name, function cb_method(raw_method) {
                            var __method = method_name;
                            return function wrapper() {
                                if ( ! agent.config.enabled ) return raw_method.apply(this, arguments);
                                var action = tracer.getAction();
                                if (! action || arguments.length < 1) return raw_method.apply(this, arguments);
                                var args = tracer.slice(arguments);
                                var last = args[args.length - 1];
                                if ( typeof last !== 'function' ) return raw_method.apply(this, arguments);

                                var addr = 'thrift://' + connection.host + ':' + connection.port + '/' + class_name + '.' + __method;
                                if ( connection.options && connection.options.path ) {
                                    addr = 'thrift://' + connection.host + ':' + connection.port + connection.options.path;
                                    connection.options.headers['TingYun'] = 'thrift';
                                }
                                var name = 'External/' + addr.replace(/\//g, "%2F") + '/' + class_name + '.' + __method;
                                var segment_info = {
                                    metric_name : name,
                                    call_url    : addr,
                                    call_count  : 1,
                                    class_name  : class_name,
                                    method_name : __method,
                                    params : {}
                                };
                                var segment = tracer.addSegment(segment_info, recordExternal(addr, segment_info.class_name + '.' + __method));
                                args[args.length - 1] = function on_back() {
                                    segment.end();
                                    return last.apply(this,arguments);
                                };
                                return raw_method.apply(this, args);
                            }
                        });
                        client[method_name].__TY_original_callback = oragin;
                    }
                }
                return ret;
            };
        });
    }
    wrap_client_method(thrift, 'Client', 'createClient');

    if (thrift.createStdIOClient) {
        wrap_client_method(thrift, 'StdIOClient', 'createStdIOClient');
    }
    if (thrift.createHttpClient) {
        wrap_client_method(thrift, 'HttpClient', 'createHttpClient');
    }
    if (thrift.Multiplexer && thrift.Multiplexer.prototype ) {
        wrap_client_method(thrift.Multiplexer.prototype, 'Multiplexer', 'createClient');
    }

};
