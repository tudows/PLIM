'use strict';

var shimmer = require('../../util/shimmer');
//var logger = require('../../util/logger').child('parsers.wrappers.ioredis');
var record = require('../../metrics/recorders/cache_storage.js')('Redis');
var cmd_map = require('./redis-common/command');

module.exports = function initialize(agent, Redis) {
    var tracer = agent.tracer;

    if (!(Redis && Redis.prototype)) {
        return;
    }

    shimmer.wrapMethod(Redis.prototype, 'Redis.prototype', 'sendCommand', function wrapper(sendCommand) {
        return tracer.segmentProxy(function wrapped(command, stream) {

            if (!agent.config.enabled || !tracer.getAction() || !arguments.length) {
                return sendCommand.apply(this, arguments);
            }

            var host, port;
            if (this.options) {
                host = this.options.host;
                port = this.options.port;
            }
            host = host || 'localhost';
            port = (port === 0) ? port : (port || 6379);

            var commandName = command.name;
            var name = 'Redis/' + host + ':' + port + '/' + cmd_map.__name_map(commandName);

            var segmentInfo = {
                metric_name: name,
                call_url: "",
                call_count: 1,
                class_name: "Redis",
                method_name: 'sendCommand.' + commandName,
                params: {}
            };
            var segment = tracer.addSegment(segmentInfo, record);
            var keyValuePair = command.args;

            if (keyValuePair && agent.config.capture_params && typeof keyValuePair !== 'function' && agent.config.ignored_params.indexOf('key') === -1) {
                segment.parameters.key = JSON.stringify([keyValuePair[0]]);
            }

            function proxy(target) {
                return function cls_finalize() {
                    segment.end();
                    return target.apply(this, arguments);
                };
            }

            var callback = command.callback,
                lastIndex;
            if (typeof callback === 'function') {
                callback = tracer.callbackProxy(proxy(callback));
            } else if (Array.isArray(callback) && typeof callback[(lastIndex = callback.length - 1)] === 'function') {
                callback[lastIndex] = tracer.callbackProxy(proxy(callback[lastIndex]));
            } else {
                callback = function() {
                    segment.end();
                };
            }

            command.callback = callback;

            return sendCommand.call(this, command, stream);
        });
    });
};