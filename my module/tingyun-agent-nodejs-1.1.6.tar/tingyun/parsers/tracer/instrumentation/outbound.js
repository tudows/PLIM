'use strict';

var recordExternal = require('../../../metrics/recorders/http_external.js')
  , urltils        = require('../../../util/urltils.js')
  , logger         = require('../../../util/logger').child('parser.tracer.instrumentation.outbound')
  ;

function instrumentOutbound(agent, request, hostname, port, href) {
  if (!hostname) throw new Error("hostname must be defined!");
  if (!port || port < 1) throw new Error("port must be defined!");
  if (port && port !== 80) hostname = hostname + ':' + port;

  var action = agent.tracer.getAction();

  var name        = 'External/' + (hostname + urltils.scrub(request.path)).replace(/\//g, "%2F") + "/request";
  var segment_info = {
    metric_name : name,
    call_url: (href? href:(request.url?request.url():"http://" + hostname + request.path)),
    call_count:1,
    class_name:"ClientRequest",
    method_name: "request",
    params : {}
  }
  var segment     = agent.tracer.addSegment(segment_info, recordExternal(hostname, 'http'));


  var params = urltils.parseParameters(request.path);
  urltils.copyParameters(agent.config, params, segment.parameters);

  // may trace errors multiple times, make that the error tracer's problem
  request.once('error', function handle_error(error) {
    agent.errors.add(action, error);
    segment.end();
  });

  // Pop off the listeners so we can make sure our response handler happens
  // first. This is to prevent a case where the action ends before our
  // response handler has had a chance to pull data it needs for segment
  // metrics.
  var existingListeners = request.listeners('response').slice();
  request.removeAllListeners('response');

  request.on('response', function handle_response(res) {
    res.once('end', segment.end.bind(segment));
  });

  // Push the listeners we popped off back onto the event. See above for
  // explaination of why.
  for (var i = 0; i < existingListeners.length; i++) {
    request.on('response', existingListeners[i]);
  }

  // ensure listeners are evaluated in correct actional scope
  agent.tracer.bindEmitter(request);
}

module.exports = instrumentOutbound;
