'use strict';
function ParsedStatement(type, operation, model) {
  this.type      = type;
  this.operation = operation;
  if ( model ) {
    var match = (/^`([^`]+)`$/gi).exec(model);
      model = match?match[1]: model;
      match = (/^"([^"]+)"$/gi).exec(model);
    this.model = (match?match[1]: model).replace(/\//g, "%2F");
  }
}
ParsedStatement.prototype.metricName = function metricName() {
  return this.type + "/" + (this.model? this.model: "NULL") + "/" + this.operation;
}

var databaseName = function databaseName(type) {
  return type;
  return ( type === "MongoDB" || type === "Redis" || type === "Memcached" ) ? type: "Database";
}

ParsedStatement.prototype.recordMetrics = function recordMetrics(segment, scope) {
  var database = databaseName(this.type);
  var duration    = segment.getDurationInMillis()
    , exclusive   = segment.getExclusiveDurationInMillis()
    , action = segment.trace.action
    , type        = database + (action.isWeb() ? '/NULL/AllWeb' : '/NULL/AllOther')
    , operation   = database + '/NULL/' + this.operation
    ;

  var name = this.metricName();
  if (this.model) action.measure(name, null, duration, exclusive);
  if (scope) action.measure(name, scope, duration, exclusive);

  action.measure(operation, null, duration, exclusive);
  action.measure(type,      null, duration, exclusive);
  action.measure(database + '/NULL/All',    null, duration, exclusive);
};

module.exports = ParsedStatement;
